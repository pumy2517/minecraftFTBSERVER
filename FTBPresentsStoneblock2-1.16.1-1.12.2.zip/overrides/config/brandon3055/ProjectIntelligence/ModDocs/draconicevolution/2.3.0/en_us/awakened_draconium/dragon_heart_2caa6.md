§align:center
##### §nThe Dragon Heart§n

§stack[draconicevolution:dragon_heart]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Dropped by the Ender Dragon and Chaos Guardian on death.
This powerful item is used to craft §link[draconicevolution:awakened_draconium]{alt_text:"Awakened Draconium"}. 

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:dragon_heart]{spacing:2}