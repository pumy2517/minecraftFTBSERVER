§align:center
##### §nWyvern Core§n

§stack[draconicevolution:wyvern_core]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
The next tier up from Draconic, this core is used in most tier 2 (wyvern) crafting recipes.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:wyvern_core]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}