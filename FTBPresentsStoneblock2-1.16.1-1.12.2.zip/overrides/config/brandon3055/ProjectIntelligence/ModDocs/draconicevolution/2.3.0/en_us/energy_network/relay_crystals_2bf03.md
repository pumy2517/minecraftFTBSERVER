§align:center
##### §nEnergy Relay Crystal§n
§stack[draconicevolution:energy_crystal,1,0]{size:64} §stack[draconicevolution:energy_crystal,1,1]{size:64} §stack[draconicevolution:energy_crystal,1,2]{size:64}
§rule{colour:0x606060,height:3,width:100%,top_pad:0}
###### §nStats

§9Basic§r
Capacity: 4 Million
Max Links: 8 

§5Wyvern§r
Capacity: 16 Million
Max Links: 16 

§6Draconic§r
Capacity: 64 Million
Max Links: 32

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:energy_crystal,1,0]{spacing:2}§recipe[draconicevolution:energy_crystal,1,1]{spacing:2}§recipe[draconicevolution:energy_crystal,1,2]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}