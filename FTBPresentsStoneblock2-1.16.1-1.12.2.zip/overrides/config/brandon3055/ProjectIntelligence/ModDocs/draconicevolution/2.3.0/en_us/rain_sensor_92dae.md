§align:center
##### §nRain Sensor§n

§stack[draconicevolution:rain_sensor]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
A device that emits a redstone signal when it rains.
(Needs to be able to see the sky)

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:rain_sensor]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}