§align:center
//##### §nDraconic Evolution§n
§table{width:100%,render_cells:false} 
<table column_layout="18,1*,18">
<tr>
	<td align="left">§img[http://ss.brandon3055.com/00671]{border_colour_hover:0x909090,width:100%,tooltip:"Подпишись на меня в Твиттере!",link_to:"https://twitter.com/Brandon3055"}</td>
	<td align="center">§img[http://ss.brandon3055.com/772e8]{width:50%}</td>
	<td align="top right">§img[http://ss.brandon3055.com/4b67c]{border_colour_hover:0x909090,width:100%,tooltip:"Поддержите мою работу на patreon!",link_to:"https://www.patreon.com/brandon3055"}</td>
</tr>
</table>

ABC...LMN§cDraconic Evolution§rQR...WXYZ
§rule{colour:0x606060,height:3,width:100%,bottom_pad:4}
Draconic Evolution - это мод, который сочетает в себе магию и технологии, предоставляя вам чрезвычайно мощный игровой контент. Ниже приведена только малая часть из всего контента, добавленного DE.
§rule{colour:0x606060,height:3,width:100%,top_pad:3,bottom_pad:0}

// ##########################################################################
§table{width:100%,render_cells:false} 
<table column_layout="25,1*"><tr><td></td><td>
§a-Мощные инструменты и броня§a
DE добавляет 2 типа брони и инструментов, которые можно улучшить.

§a-Телепортация§a
Среди прочего, DE в настоящее время является единственным модом, который позволяет телепортироваться с точки на точку, даже через измерения, а также сохранять эти точки для дальнейшей телепортации на них.

§a-Контроль над временем и погодой§a
Добавляет возможность начать или остановить дождь/шторм. А также возможность пропустить ночь или день, если вы этого захотите.

§a-Ферма существ§a
Позволяет автоматически спаунить и убивать существ
          
§a-Практически бесконечное энергохранилище§a
В мире  minecraft нет ничего бесконечного, но похоже вы уже близко!

§a-Экстремальное (опасное) производство энергии§a
С большой силой приходит больщой потенциал для разрушения. Реактор DE не является исключением. Если вы не будете осторожны, он с радостью разрушит весь ваш мир!

§a-Причудливые визуальные эффекты!§a
Кому не нравятся причудливые визуальные эффекты?!

§a-Одного из самых мощных боссов из всех модификаций на minecraft§a
Зачарованная алмазная броня? Возможно, Вам повезет больше, если вы завернетесь в папиросную бумагу...
</td></tr></table>

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
// ##########################################################################
§table{width:100%,render_cells:false} 
<table column_layout="1*,130">
<tr>
	<td>Я хочу поблагодарить всех, кто сделал видео-обзоры для этого мода! Вы можете найти список их по ссылке ниже.</td>
	<td align="middle right">§link[draconicevolution:spotlights]{alt_text:Mod Spotlights,colour:0xE0E0E0,colour_hover:0xFFFFA0,padding:5,left_pad:12,right_pad:13,link_style:vanilla}</td>
</tr>
</table>
§rule{colour:0x606060,height:3,width:100%,top_pad:4}
// ##########################################################################
§table{width:100%,render_cells:false} 
<table column_layout="1*,100">
<tr>
	<td>Я также хотел бы поблагодарить всех, кто так или иначе поддерживал DE на протяжении многих лет!</td>
    <td align="middle right">§link[draconicevolution:contributors]{alt_text:Mod Contributors,colour:0xE0E0E0,colour_hover:0xFFFFA0,padding:5,link_style:vanilla}</td>
</tr>
</table>
§rule{colour:0x606060,height:3,width:100%,top_pad:5}
// ##########################################################################

§align:left
§table{width:100%,colour:0x0,render_cells:false} 
<table column_layout="1*,90">
<tr padding="2,0,1,3" align="middle">
	<td>§colour[0x088700]§link[http://partners.creeper.host/r/brandon30557nc]{tooltip:"Используйте эту ссылку, чтобы получить скидку 15% в первый месяц!",alt_text: Я сотрудничаю с Creeper Host. Если вам нужно арендовать сервер по разумной цене то я предлагаю вам взглянуть на них!}</td>
	<td>§img[http://ss.brandon3055.com/0f927]{tooltip:"Use this link to get a 15% discount on your first month!",width:100%,link_to:"http://partners.creeper.host/r/brandon30557nc"}</td>
</tr>
</table>