§align:center
###### §nBig Item Filter§n
§stack[enderio:item_big_item_filter]{size:18,enable_tooltip:false} 
§align:left
The Big Item Filter allows you to filter for up to 36 items

It supports the same options as the §link[enderio:basic_item_filter]{alt_text:"Basic Item Filter"}.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}

§recipe[enderio:item_big_item_filter]{spacing:4}