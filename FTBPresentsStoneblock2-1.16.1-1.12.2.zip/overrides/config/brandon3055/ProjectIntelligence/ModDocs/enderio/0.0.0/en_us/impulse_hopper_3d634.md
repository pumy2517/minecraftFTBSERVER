§stack[enderio:block_impulse_hopper]{size:18,enable_tooltip:false}

§recipe[enderio:block_impulse_hopper]{spacing:4}