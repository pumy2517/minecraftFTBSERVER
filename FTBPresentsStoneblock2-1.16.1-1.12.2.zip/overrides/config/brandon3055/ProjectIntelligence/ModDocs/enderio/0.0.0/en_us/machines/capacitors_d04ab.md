§align:center
###### §nCapacitors§n
§stack[enderio:item_basic_capacitor]{size:18,enable_tooltip:false} §stack[enderio:item_basic_capacitor,1,1]{size:18,enable_tooltip:false} §stack[enderio:item_basic_capacitor,1,2]{size:18,enable_tooltip:false} §stack[enderio:item_basic_capacitor,1,3]{size:18,enable_tooltip:false} §stack[enderio:item_basic_capacitor,1,4]{size:18,enable_tooltip:false} 
§align:left
§4§nNote:§r The Endergy addon adds even more types of capacitors.

Capacitors are what enables machines and items to store power. Better capacitor increase the amount of power that can be stored and make the machine or item more effective. A machine may run faster, or have a larger range, or generate more power.

"Loot Capacitors" are special capacitors that can only be found in loot chests. They give random boosts to random machines. Check their description and experiment with them to find out what they do and how good they are. Loot capacitors of the same type can be combined in an anvil; this generally produces a better capacitor.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}

§recipe[enderio:item_basic_capacitor]{spacing:4}
§recipe[enderio:item_basic_capacitor,1,1]{spacing:4}
§recipe[enderio:item_basic_capacitor,1,2]{spacing:4}
