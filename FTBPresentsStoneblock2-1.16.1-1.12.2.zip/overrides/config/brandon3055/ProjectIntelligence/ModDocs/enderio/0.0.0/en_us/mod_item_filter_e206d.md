§align:center
###### §nMod Item Filter§n
§stack[enderio:item_mod_item_filter]{size:18,enable_tooltip:false}  
§align:left
The Mod Item Filter allows you to filter based upon the mod an item belongs to. It has slots for up to 3 mods.

Place an item into the leftmost box to set the filter to the mod that item belongs to. Press the "-" button to delete an entry.

It can be switched between whitelist (only items listed are allowed) and blacklist (all items *but* the listed ones are allowed.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}

§recipe[enderio:item_mod_item_filter]{spacing:4}