§stack[enderio:block_tele_pad]{size:18,enable_tooltip:false}

§recipe[enderio:block_tele_pad]{spacing:4}