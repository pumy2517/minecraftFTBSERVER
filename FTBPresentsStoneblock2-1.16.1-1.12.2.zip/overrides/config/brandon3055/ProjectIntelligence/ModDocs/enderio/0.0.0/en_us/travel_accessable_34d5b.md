§stack[enderio:block_travel_anchor]{size:18,enable_tooltip:false}§stack[enderio:block_tele_pad]{size:18,enable_tooltip:false}

§recipe[enderio:block_travel_anchor]{spacing:4}