§stack[enderio:block_simple_wired_charger]{size:18,enable_tooltip:false}§stack[enderio:block_wired_charger]{size:18,enable_tooltip:false}§stack[enderio:block_enhanced_wired_charger]{size:18,enable_tooltip:false}

§recipe[enderio:block_simple_wired_charger]{spacing:4}
§recipe[enderio:block_wired_charger]{spacing:4}
§recipe[enderio:block_enhanced_wired_charger]{spacing:4}